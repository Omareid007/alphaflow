"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { store } from "@/lib/store";
import { Strategy, PortfolioSnapshot, AiEvent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp,
  TrendingDown,
  Plus,
  ArrowRight,
  Activity,
  AlertTriangle,
  Brain,
  Zap
} from "lucide-react";
import { cn } from "@/lib/utils";

function MetricCard({
  title,
  value,
  change,
  changeLabel,
  icon: Icon
}: {
  title: string;
  value: string;
  change?: number;
  changeLabel?: string;
  icon: React.ElementType;
}) {
  const isPositive = change !== undefined && change >= 0;

  return (
    <Card className="bg-card">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="mt-2 text-3xl font-semibold tracking-tight">{value}</p>
            {change !== undefined && (
              <div className="mt-2 flex items-center gap-1">
                {isPositive ? (
                  <TrendingUp className="h-4 w-4 text-success" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-destructive" />
                )}
                <span
                  className={cn(
                    "text-sm font-medium",
                    isPositive ? "text-success" : "text-destructive"
                  )}
                >
                  {isPositive ? "+" : ""}
                  {change.toFixed(2)}%
                </span>
                {changeLabel && (
                  <span className="text-sm text-muted-foreground">
                    {changeLabel}
                  </span>
                )}
              </div>
            )}
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
            <Icon className="h-6 w-6 text-muted-foreground" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function StrategyCard({ strategy }: { strategy: Strategy }) {
  const statusColors: Record<string, string> = {
    Draft: "bg-muted text-muted-foreground",
    Backtested: "bg-blue-500/10 text-blue-500",
    Deployed: "bg-success/10 text-success",
    Paused: "bg-warning/10 text-warning",
    Stopped: "bg-destructive/10 text-destructive"
  };

  return (
    <Card className="group transition-colors hover:bg-secondary/50">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-3">
              <h3 className="truncate font-medium">{strategy.name}</h3>
              <Badge variant="secondary" className={statusColors[strategy.status]}>
                {strategy.status}
              </Badge>
            </div>
            {strategy.performanceSummary && (
              <div className="mt-2 flex items-center gap-4 text-sm">
                <span className="text-muted-foreground">
                  Return:{" "}
                  <span
                    className={
                      strategy.performanceSummary.totalReturn >= 0
                        ? "text-success"
                        : "text-destructive"
                    }
                  >
                    {strategy.performanceSummary.totalReturn >= 0 ? "+" : ""}
                    {strategy.performanceSummary.totalReturn.toFixed(1)}%
                  </span>
                </span>
                <span className="text-muted-foreground">
                  Sharpe: {strategy.performanceSummary.sharpe.toFixed(2)}
                </span>
              </div>
            )}
          </div>
          <Link href={`/strategies/${strategy.id}`}>
            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

function AiEventCard({ event }: { event: AiEvent }) {
  const typeIcons: Record<string, React.ElementType> = {
    signal: Zap,
    sentiment: Activity,
    news: Brain,
    risk: AlertTriangle,
    suggestion: Brain
  };

  const typeColors: Record<string, string> = {
    signal: "text-primary",
    sentiment: "text-blue-400",
    news: "text-muted-foreground",
    risk: "text-warning",
    suggestion: "text-success"
  };

  const Icon = typeIcons[event.type] || Brain;

  return (
    <div className="flex gap-3 py-3">
      <div className={cn("mt-0.5", typeColors[event.type])}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium">{event.headline}</p>
        <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
          {event.explanation}
        </p>
        <div className="mt-2 flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {new Date(event.time).toLocaleString()}
          </span>
          {event.symbol && (
            <Badge variant="outline" className="text-xs">
              {event.symbol}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  const [portfolio, setPortfolio] = useState<PortfolioSnapshot | null>(null);
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [events, setEvents] = useState<AiEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      const [portfolioData, strategiesData, eventsData] = await Promise.all([
        store.getPortfolioSnapshot(),
        store.getStrategies(),
        store.getAiEvents()
      ]);
      setPortfolio(portfolioData);
      setStrategies(strategiesData);
      setEvents(eventsData);
      setLoading(false);
    }
    loadData();
  }, []);

  const activeStrategies = strategies.filter(s => s.status === "Deployed");

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
          <p className="mt-1 text-muted-foreground">
            Overview of your trading performance
          </p>
        </div>
        <Link href="/create">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Strategy
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Equity"
          value={`$${portfolio?.equity.toLocaleString() ?? "0"}`}
          change={portfolio?.dayPLPercent}
          changeLabel="today"
          icon={TrendingUp}
        />
        <MetricCard
          title="Day P&L"
          value={`$${portfolio?.dayPL.toLocaleString() ?? "0"}`}
          change={portfolio?.dayPLPercent}
          icon={Activity}
        />
        <MetricCard
          title="Active Strategies"
          value={activeStrategies.length.toString()}
          icon={Zap}
        />
        <MetricCard
          title="Current Drawdown"
          value={`${portfolio?.drawdown.toFixed(1) ?? "0"}%`}
          icon={AlertTriangle}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Strategies</CardTitle>
              <Link href="/strategies">
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="space-y-2">
              {strategies.length === 0 ? (
                <div className="py-8 text-center">
                  <p className="text-muted-foreground">No strategies yet</p>
                  <Link href="/create">
                    <Button variant="outline" className="mt-4">
                      Create your first strategy
                    </Button>
                  </Link>
                </div>
              ) : (
                strategies.slice(0, 5).map(strategy => (
                  <StrategyCard key={strategy.id} strategy={strategy} />
                ))
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">AI Activity</CardTitle>
              <Link href="/ai">
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="divide-y divide-border">
                {events.slice(0, 5).map(event => (
                  <AiEventCard key={event.id} event={event} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
