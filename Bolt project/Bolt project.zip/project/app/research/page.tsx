"use client";

import { useEffect, useState } from "react";
import { store } from "@/lib/store";
import { Watchlist, WatchlistItem } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import {
  Search,
  Plus,
  X,
  TrendingUp,
  TrendingDown,
  Star,
  CheckCircle,
  XCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const availableSymbols = [
  { symbol: "AAPL", name: "Apple Inc", price: 178.52 },
  { symbol: "MSFT", name: "Microsoft Corp", price: 378.91 },
  { symbol: "GOOGL", name: "Alphabet Inc", price: 141.80 },
  { symbol: "AMZN", name: "Amazon.com Inc", price: 178.25 },
  { symbol: "NVDA", name: "NVIDIA Corp", price: 495.22 },
  { symbol: "TSLA", name: "Tesla Inc", price: 248.48 },
  { symbol: "META", name: "Meta Platforms", price: 505.95 },
  { symbol: "JPM", name: "JPMorgan Chase", price: 183.27 },
  { symbol: "V", name: "Visa Inc", price: 279.53 },
  { symbol: "JNJ", name: "Johnson & Johnson", price: 156.74 },
  { symbol: "WMT", name: "Walmart Inc", price: 163.42 },
  { symbol: "PG", name: "Procter & Gamble", price: 147.89 }
];

export default function ResearchPage() {
  const [watchlists, setWatchlists] = useState<Watchlist[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeWatchlist, setActiveWatchlist] = useState<string | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState(false);

  const loadWatchlists = async () => {
    const data = await store.getWatchlists();
    setWatchlists(data);
    if (data.length > 0 && !activeWatchlist) {
      setActiveWatchlist(data[0].id);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadWatchlists();
  }, []);

  const currentWatchlist = watchlists.find(w => w.id === activeWatchlist);

  const filteredItems = currentWatchlist?.items.filter(item =>
    item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleAddSymbol = async (symbol: string) => {
    if (!activeWatchlist) return;
    await store.addToWatchlist(activeWatchlist, symbol);
    toast.success(`${symbol} added to watchlist`);
    loadWatchlists();
    setAddDialogOpen(false);
  };

  const handleRemoveSymbol = async (symbol: string) => {
    if (!activeWatchlist) return;
    await store.removeFromWatchlist(activeWatchlist, symbol);
    toast.success(`${symbol} removed from watchlist`);
    loadWatchlists();
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  const symbolsInWatchlist = currentWatchlist?.items.map(i => i.symbol) || [];
  const availableToAdd = availableSymbols.filter(s => !symbolsInWatchlist.includes(s.symbol));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Research</h1>
        <p className="mt-1 text-muted-foreground">
          Manage your watchlists and research universe
        </p>
      </div>

      <Tabs value={activeWatchlist || ""} onValueChange={setActiveWatchlist}>
        <div className="flex items-center justify-between">
          <TabsList>
            {watchlists.map(wl => (
              <TabsTrigger key={wl.id} value={wl.id}>
                <Star className="mr-2 h-4 w-4" />
                {wl.name}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search symbols..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-60 pl-9"
              />
            </div>
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Symbol
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Symbol to Watchlist</DialogTitle>
                </DialogHeader>
                <div className="max-h-96 space-y-2 overflow-auto">
                  {availableToAdd.length === 0 ? (
                    <p className="py-4 text-center text-muted-foreground">
                      All available symbols are already in your watchlist
                    </p>
                  ) : (
                    availableToAdd.map(item => (
                      <button
                        key={item.symbol}
                        onClick={() => handleAddSymbol(item.symbol)}
                        className="flex w-full items-center justify-between rounded-lg p-3 transition-colors hover:bg-secondary"
                      >
                        <div className="text-left">
                          <p className="font-medium">{item.symbol}</p>
                          <p className="text-sm text-muted-foreground">{item.name}</p>
                        </div>
                        <span className="text-muted-foreground">${item.price.toFixed(2)}</span>
                      </button>
                    ))
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {watchlists.map(wl => (
          <TabsContent key={wl.id} value={wl.id} className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{wl.name}</CardTitle>
                  <span className="text-sm text-muted-foreground">
                    {wl.items.length} symbols
                  </span>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {filteredItems.length === 0 ? (
                  <div className="py-12 text-center">
                    <p className="text-muted-foreground">
                      {searchQuery ? "No symbols match your search" : "No symbols in this watchlist"}
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead className="text-right">Price</TableHead>
                        <TableHead className="text-right">Change</TableHead>
                        <TableHead>Tags</TableHead>
                        <TableHead>Eligible</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.map(item => (
                        <TableRow key={item.symbol}>
                          <TableCell className="font-semibold">{item.symbol}</TableCell>
                          <TableCell className="text-muted-foreground">{item.name}</TableCell>
                          <TableCell className="text-right">${item.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              {item.change >= 0 ? (
                                <TrendingUp className="h-4 w-4 text-success" />
                              ) : (
                                <TrendingDown className="h-4 w-4 text-destructive" />
                              )}
                              <span className={item.change >= 0 ? "text-success" : "text-destructive"}>
                                {item.change >= 0 ? "+" : ""}${item.change.toFixed(2)} ({item.changePercent.toFixed(2)}%)
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {item.tags.map(tag => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            {item.eligible ? (
                              <CheckCircle className="h-4 w-4 text-success" />
                            ) : (
                              <XCircle className="h-4 w-4 text-muted-foreground" />
                            )}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemoveSymbol(item.symbol)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <TrendingUp className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Top Gainer</p>
                <p className="text-xl font-semibold">
                  {currentWatchlist?.items.sort((a, b) => b.changePercent - a.changePercent)[0]?.symbol || "-"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10">
                <TrendingDown className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Top Loser</p>
                <p className="text-xl font-semibold">
                  {currentWatchlist?.items.sort((a, b) => a.changePercent - b.changePercent)[0]?.symbol || "-"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Eligible for Trading</p>
                <p className="text-xl font-semibold">
                  {currentWatchlist?.items.filter(i => i.eligible).length || 0}/{currentWatchlist?.items.length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
