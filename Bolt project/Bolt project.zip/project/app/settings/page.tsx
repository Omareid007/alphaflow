"use client";

import { useState, useEffect } from "react";
import { store } from "@/lib/store";
import { UserSettings } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import {
  Bell,
  Shield,
  Moon,
  Sun,
  AlertTriangle,
  Wallet,
  TrendingDown,
  Clock,
  Check
} from "lucide-react";
import { useTheme } from "next-themes";
import { toast } from "sonner";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const data = store.getSettings();
    setSettings(data);
    setLoading(false);
  }, []);

  const handleNotificationChange = (key: keyof UserSettings["notifications"], value: boolean) => {
    if (!settings) return;
    const updated = {
      ...settings,
      notifications: { ...settings.notifications, [key]: value }
    };
    setSettings(updated);
    store.updateSettings(updated);
    toast.success("Settings saved");
  };

  const handleGuardrailChange = (key: keyof UserSettings["riskGuardrails"], value: number | boolean) => {
    if (!settings) return;
    const updated = {
      ...settings,
      riskGuardrails: { ...settings.riskGuardrails, [key]: value }
    };
    setSettings(updated);
    store.updateSettings(updated);
    toast.success("Settings saved");
  };

  if (loading || !settings) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-1 text-muted-foreground">
          Manage your account and preferences
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            {theme === "dark" ? (
              <Moon className="h-5 w-5 text-muted-foreground" />
            ) : (
              <Sun className="h-5 w-5 text-muted-foreground" />
            )}
            <div>
              <CardTitle className="text-lg">Appearance</CardTitle>
              <CardDescription>Customize the look and feel</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label>Theme</Label>
              <p className="text-sm text-muted-foreground">
                Switch between light and dark mode
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant={theme === "light" ? "default" : "outline"}
                size="sm"
                onClick={() => setTheme("light")}
              >
                <Sun className="mr-2 h-4 w-4" />
                Light
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "outline"}
                size="sm"
                onClick={() => setTheme("dark")}
              >
                <Moon className="mr-2 h-4 w-4" />
                Dark
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5 text-muted-foreground" />
            <div>
              <CardTitle className="text-lg">Notifications</CardTitle>
              <CardDescription>Configure alert preferences</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label>Trade Notifications</Label>
              <p className="text-sm text-muted-foreground">
                Receive alerts for order executions
              </p>
            </div>
            <Switch
              checked={settings.notifications.trades}
              onCheckedChange={v => handleNotificationChange("trades", v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <Label>AI Alerts</Label>
              <p className="text-sm text-muted-foreground">
                Receive AI-generated signals and insights
              </p>
            </div>
            <Switch
              checked={settings.notifications.aiAlerts}
              onCheckedChange={v => handleNotificationChange("aiAlerts", v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <Label>Risk Warnings</Label>
              <p className="text-sm text-muted-foreground">
                Get notified about risk threshold breaches
              </p>
            </div>
            <Switch
              checked={settings.notifications.riskWarnings}
              onCheckedChange={v => handleNotificationChange("riskWarnings", v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <Label>Daily Digest</Label>
              <p className="text-sm text-muted-foreground">
                Receive a daily summary email
              </p>
            </div>
            <Switch
              checked={settings.notifications.dailyDigest}
              onCheckedChange={v => handleNotificationChange("dailyDigest", v)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Shield className="h-5 w-5 text-muted-foreground" />
            <div>
              <CardTitle className="text-lg">Risk Guardrails</CardTitle>
              <CardDescription>Set safety limits for your strategies</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-muted-foreground" />
                <Label>Max Position Size</Label>
              </div>
              <span className="rounded-md bg-secondary px-3 py-1 text-sm font-medium">
                {settings.riskGuardrails.maxPositionSize}%
              </span>
            </div>
            <Slider
              value={[settings.riskGuardrails.maxPositionSize]}
              onValueChange={([v]) => handleGuardrailChange("maxPositionSize", v)}
              min={5}
              max={50}
              step={5}
            />
            <p className="text-xs text-muted-foreground">
              Maximum size of any single position as a percentage of portfolio
            </p>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
                <Label>Max Drawdown</Label>
              </div>
              <span className="rounded-md bg-secondary px-3 py-1 text-sm font-medium">
                {settings.riskGuardrails.maxDrawdown}%
              </span>
            </div>
            <Slider
              value={[settings.riskGuardrails.maxDrawdown]}
              onValueChange={([v]) => handleGuardrailChange("maxDrawdown", v)}
              min={5}
              max={50}
              step={5}
            />
            <p className="text-xs text-muted-foreground">
              Pause strategy if portfolio drawdown exceeds this threshold
            </p>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                <Label>Max Daily Loss</Label>
              </div>
              <span className="rounded-md bg-secondary px-3 py-1 text-sm font-medium">
                {settings.riskGuardrails.maxDailyLoss}%
              </span>
            </div>
            <Slider
              value={[settings.riskGuardrails.maxDailyLoss]}
              onValueChange={([v]) => handleGuardrailChange("maxDailyLoss", v)}
              min={1}
              max={20}
              step={1}
            />
            <p className="text-xs text-muted-foreground">
              Halt all trading for the day if losses exceed this amount
            </p>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-muted-foreground" />
                <Label>Require Confirmation</Label>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                Require manual confirmation before executing large trades
              </p>
            </div>
            <Switch
              checked={settings.riskGuardrails.requireConfirmation}
              onCheckedChange={v => handleGuardrailChange("requireConfirmation", v)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <div>
              <CardTitle className="text-lg">Connections</CardTitle>
              <CardDescription>Broker and data feed integrations</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="font-medium">Brokerage Account</p>
              <p className="text-sm text-muted-foreground">Connect your trading account</p>
            </div>
            <Button variant="outline" disabled>
              Coming Soon
            </Button>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="font-medium">Market Data Feed</p>
              <p className="text-sm text-muted-foreground">Real-time market data provider</p>
            </div>
            <Button variant="outline" disabled>
              Coming Soon
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
