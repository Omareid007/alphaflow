"use client";

import { useEffect, useState } from "react";
import { store } from "@/lib/store";
import { PortfolioSnapshot, Strategy } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart as PieIcon,
  AlertTriangle,
  Wallet
} from "lucide-react";
import { cn } from "@/lib/utils";

const COLORS = ["hsl(199, 89%, 48%)", "hsl(152, 69%, 45%)", "hsl(43, 96%, 56%)", "hsl(0, 72%, 51%)", "hsl(220, 14%, 50%)"];

function MetricCard({
  title,
  value,
  change,
  icon: Icon,
  variant = "default"
}: {
  title: string;
  value: string;
  change?: number;
  icon: React.ElementType;
  variant?: "default" | "success" | "warning" | "danger";
}) {
  const variantStyles = {
    default: "text-foreground",
    success: "text-success",
    warning: "text-warning",
    danger: "text-destructive"
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className={cn("mt-2 text-3xl font-semibold", variantStyles[variant])}>{value}</p>
            {change !== undefined && (
              <div className="mt-2 flex items-center gap-1">
                {change >= 0 ? (
                  <TrendingUp className="h-4 w-4 text-success" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-destructive" />
                )}
                <span className={change >= 0 ? "text-sm text-success" : "text-sm text-destructive"}>
                  {change >= 0 ? "+" : ""}{change.toFixed(2)}%
                </span>
              </div>
            )}
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
            <Icon className="h-6 w-6 text-muted-foreground" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PortfolioPage() {
  const [portfolio, setPortfolio] = useState<PortfolioSnapshot | null>(null);
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [portfolioData, strategiesData] = await Promise.all([
        store.getPortfolioSnapshot(),
        store.getStrategies()
      ]);
      setPortfolio(portfolioData);
      setStrategies(strategiesData);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!portfolio) return null;

  const pieData = portfolio.allocations.map(a => ({
    name: a.symbol,
    value: a.weight
  }));

  const pnlData = portfolio.allocations.map(a => ({
    symbol: a.symbol,
    pnl: a.pnl,
    pnlPercent: a.pnlPercent
  }));

  const exposedAmount = portfolio.equity - portfolio.cash;
  const cashPercent = (portfolio.cash / portfolio.equity) * 100;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Portfolio</h1>
        <p className="mt-1 text-muted-foreground">
          View your positions, allocations, and risk metrics
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Equity"
          value={`$${portfolio.equity.toLocaleString()}`}
          change={portfolio.dayPLPercent}
          icon={DollarSign}
        />
        <MetricCard
          title="Day P&L"
          value={`$${portfolio.dayPL.toLocaleString()}`}
          change={portfolio.dayPLPercent}
          icon={TrendingUp}
          variant={portfolio.dayPL >= 0 ? "success" : "danger"}
        />
        <MetricCard
          title="Exposure"
          value={`${portfolio.exposure.toFixed(1)}%`}
          icon={PieIcon}
        />
        <MetricCard
          title="Drawdown"
          value={`${portfolio.drawdown.toFixed(1)}%`}
          icon={AlertTriangle}
          variant={portfolio.drawdown > 10 ? "warning" : "default"}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Asset Allocation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      return (
                        <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                          <p className="font-medium">{payload[0].name}</p>
                          <p className="text-sm text-muted-foreground">
                            {Number(payload[0].value).toFixed(1)}%
                          </p>
                        </div>
                      );
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Position P&L</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pnlData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" tickFormatter={v => `$${v}`} />
                  <YAxis type="category" dataKey="symbol" width={50} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                          <p className="font-medium">{data.symbol}</p>
                          <p className={cn("text-sm", data.pnl >= 0 ? "text-success" : "text-destructive")}>
                            ${data.pnl.toLocaleString()} ({data.pnlPercent.toFixed(1)}%)
                          </p>
                        </div>
                      );
                    }}
                  />
                  <Bar
                    dataKey="pnl"
                    fill="hsl(var(--primary))"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Cash & Exposure</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Cash Available</span>
                <span className="font-medium">${portfolio.cash.toLocaleString()}</span>
              </div>
              <Progress value={cashPercent} className="h-2" />
              <p className="text-xs text-muted-foreground">{cashPercent.toFixed(1)}% of portfolio</p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Invested</span>
                <span className="font-medium">${exposedAmount.toLocaleString()}</span>
              </div>
              <Progress value={100 - cashPercent} className="h-2" />
              <p className="text-xs text-muted-foreground">{(100 - cashPercent).toFixed(1)}% of portfolio</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Active Strategies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {strategies.filter(s => s.status === "Deployed").length === 0 ? (
              <p className="text-muted-foreground">No active strategies</p>
            ) : (
              strategies
                .filter(s => s.status === "Deployed")
                .map(strategy => (
                  <div key={strategy.id} className="flex items-center justify-between rounded-lg bg-secondary/50 p-4">
                    <div>
                      <p className="font-medium">{strategy.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {store.getTemplate(strategy.templateId)?.name}
                      </p>
                    </div>
                    {strategy.performanceSummary && (
                      <div className="text-right">
                        <p
                          className={cn(
                            "font-semibold",
                            strategy.performanceSummary.dayReturn >= 0 ? "text-success" : "text-destructive"
                          )}
                        >
                          {strategy.performanceSummary.dayReturn >= 0 ? "+" : ""}
                          {strategy.performanceSummary.dayReturn.toFixed(2)}%
                        </p>
                        <p className="text-sm text-muted-foreground">Today</p>
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
