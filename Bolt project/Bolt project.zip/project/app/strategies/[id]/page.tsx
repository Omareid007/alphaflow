"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { store } from "@/lib/store";
import { Strategy, BacktestRun, AlgorithmTemplate } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import {
  ArrowLeft,
  Play,
  Pause,
  Square,
  Pencil,
  RotateCcw,
  Rocket,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Settings
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const statusConfig: Record<string, { color: string; label: string }> = {
  Draft: { color: "bg-muted text-muted-foreground", label: "Draft" },
  Backtested: { color: "bg-blue-500/10 text-blue-500", label: "Backtested" },
  Deployed: { color: "bg-success/10 text-success", label: "Active" },
  Paused: { color: "bg-warning/10 text-warning", label: "Paused" },
  Stopped: { color: "bg-destructive/10 text-destructive", label: "Stopped" }
};

export default function StrategyDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [strategy, setStrategy] = useState<Strategy | null>(null);
  const [template, setTemplate] = useState<AlgorithmTemplate | null>(null);
  const [backtest, setBacktest] = useState<BacktestRun | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const strat = await store.getStrategy(id);
      if (!strat) {
        router.push("/strategies");
        return;
      }
      setStrategy(strat);
      setTemplate(store.getTemplate(strat.templateId) || null);

      if (strat.lastBacktestId) {
        const bt = await store.getBacktest(strat.lastBacktestId);
        setBacktest(bt || null);
      }
      setLoading(false);
    }
    load();
  }, [id, router]);

  const handlePause = async () => {
    if (!strategy) return;
    await store.pauseStrategy(strategy.id);
    toast.success("Strategy paused");
    const updated = await store.getStrategy(id);
    setStrategy(updated || null);
  };

  const handleResume = async () => {
    if (!strategy) return;
    await store.resumeStrategy(strategy.id);
    toast.success("Strategy resumed");
    const updated = await store.getStrategy(id);
    setStrategy(updated || null);
  };

  const handleStop = async () => {
    if (!strategy) return;
    await store.stopStrategy(strategy.id);
    toast.success("Strategy stopped");
    const updated = await store.getStrategy(id);
    setStrategy(updated || null);
  };

  const handleDeploy = async (mode: "paper" | "live") => {
    if (!strategy) return;
    await store.deployStrategy(strategy.id, mode);
    toast.success(`Deployed to ${mode} trading`);
    const updated = await store.getStrategy(id);
    setStrategy(updated || null);
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!strategy) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/strategies">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-semibold tracking-tight">{strategy.name}</h1>
            <Badge variant="secondary" className={statusConfig[strategy.status].color}>
              {statusConfig[strategy.status].label}
            </Badge>
          </div>
          <p className="mt-1 text-muted-foreground">{template?.name}</p>
        </div>
        <div className="flex gap-2">
          {strategy.status === "Deployed" && (
            <Button variant="outline" onClick={handlePause}>
              <Pause className="mr-2 h-4 w-4" />
              Pause
            </Button>
          )}
          {strategy.status === "Paused" && (
            <>
              <Button variant="outline" onClick={handleResume}>
                <Play className="mr-2 h-4 w-4" />
                Resume
              </Button>
              <Button variant="outline" onClick={handleStop}>
                <Square className="mr-2 h-4 w-4" />
                Stop
              </Button>
            </>
          )}
          {(strategy.status === "Backtested" || strategy.status === "Stopped") && (
            <>
              <Button variant="outline" onClick={() => handleDeploy("paper")}>
                <Play className="mr-2 h-4 w-4" />
                Paper Trade
              </Button>
              <Button onClick={() => handleDeploy("live")}>
                <Rocket className="mr-2 h-4 w-4" />
                Go Live
              </Button>
            </>
          )}
          <Link href={`/strategies/${id}/edit`}>
            <Button variant="outline">
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {strategy.performanceSummary && (
          <>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Total Return</p>
                <p
                  className={cn(
                    "mt-1 text-2xl font-semibold",
                    strategy.performanceSummary.totalReturn >= 0 ? "text-success" : "text-destructive"
                  )}
                >
                  {strategy.performanceSummary.totalReturn >= 0 ? "+" : ""}
                  {strategy.performanceSummary.totalReturn.toFixed(1)}%
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Sharpe Ratio</p>
                <p className="mt-1 text-2xl font-semibold">
                  {strategy.performanceSummary.sharpe.toFixed(2)}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Max Drawdown</p>
                <p className="mt-1 text-2xl font-semibold text-warning">
                  -{strategy.performanceSummary.maxDrawdown.toFixed(1)}%
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="mt-1 text-2xl font-semibold">
                  {strategy.performanceSummary.winRate.toFixed(0)}%
                </p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Tabs defaultValue="performance">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="config">Configuration</TabsTrigger>
          {backtest && <TabsTrigger value="interpretation">AI Analysis</TabsTrigger>}
        </TabsList>

        <TabsContent value="performance" className="mt-4">
          {backtest ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Equity Curve</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={backtest.chartSeries.equityCurve}>
                      <defs>
                        <linearGradient id="eqGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="date"
                        tickFormatter={d => new Date(d).toLocaleDateString("en-US", { month: "short" })}
                      />
                      <YAxis tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (!active || !payload?.length) return null;
                          return (
                            <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                              <p className="text-sm text-muted-foreground">
                                {new Date(payload[0].payload.date).toLocaleDateString()}
                              </p>
                              <p className="text-lg font-semibold">
                                ${payload[0].value?.toLocaleString()}
                              </p>
                            </div>
                          );
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        fill="url(#eqGradient)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No backtest data available</p>
                <Link href={`/strategies/${id}/edit`}>
                  <Button className="mt-4">Run Backtest</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="config" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Strategy Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {template?.stepSchema.steps.map(step =>
                  step.fields.map(field => (
                    <div key={field.key} className="rounded-lg bg-secondary/50 p-4">
                      <p className="text-sm text-muted-foreground">{field.label}</p>
                      <p className="mt-1 font-medium">
                        {Array.isArray(strategy.configValues[field.key])
                          ? (strategy.configValues[field.key] as string[]).join(", ")
                          : String(strategy.configValues[field.key])}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {backtest && (
          <TabsContent value="interpretation" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">AI Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">{backtest.interpretation.summary}</p>

                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h4 className="mb-3 flex items-center gap-2 font-medium">
                      <CheckCircle className="h-4 w-4 text-success" />
                      Strengths
                    </h4>
                    <ul className="space-y-2">
                      {backtest.interpretation.strengths.map((s, i) => (
                        <li key={i} className="text-sm text-muted-foreground">{s}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="mb-3 flex items-center gap-2 font-medium">
                      <AlertTriangle className="h-4 w-4 text-warning" />
                      Risks
                    </h4>
                    <ul className="space-y-2">
                      {backtest.interpretation.risks.map((r, i) => (
                        <li key={i} className="text-sm text-muted-foreground">{r}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
