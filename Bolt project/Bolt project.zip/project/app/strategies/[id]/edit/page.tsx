"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { store } from "@/lib/store";
import { Strategy, BacktestRun } from "@/lib/types";
import { StrategyWizard } from "@/components/wizard/strategy-wizard";

export default function EditStrategyPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [strategy, setStrategy] = useState<Strategy | null>(null);
  const [backtest, setBacktest] = useState<BacktestRun | undefined>(undefined);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const strat = await store.getStrategy(id);
      if (!strat) {
        router.push("/strategies");
        return;
      }
      setStrategy(strat);

      if (strat.lastBacktestId) {
        const bt = await store.getBacktest(strat.lastBacktestId);
        setBacktest(bt || undefined);
      }
      setLoading(false);
    }
    load();
  }, [id, router]);

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!strategy) return null;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold tracking-tight">Edit Strategy</h1>
        <p className="mt-1 text-muted-foreground">
          Modify configuration and run new backtests
        </p>
      </div>
      <StrategyWizard existingStrategy={strategy} existingBacktest={backtest} />
    </div>
  );
}
