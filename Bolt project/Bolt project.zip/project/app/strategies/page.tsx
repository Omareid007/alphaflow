"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { store } from "@/lib/store";
import { Strategy } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import {
  Plus,
  MoreHorizontal,
  Play,
  Pause,
  Square,
  Pencil,
  Copy,
  Trash2,
  TrendingUp,
  TrendingDown,
  ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const statusConfig: Record<string, { color: string; label: string }> = {
  Draft: { color: "bg-muted text-muted-foreground", label: "Draft" },
  Backtested: { color: "bg-blue-500/10 text-blue-500", label: "Backtested" },
  Deployed: { color: "bg-success/10 text-success", label: "Active" },
  Paused: { color: "bg-warning/10 text-warning", label: "Paused" },
  Stopped: { color: "bg-destructive/10 text-destructive", label: "Stopped" }
};

export default function StrategiesPage() {
  const router = useRouter();
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const loadStrategies = async () => {
    const data = await store.getStrategies();
    setStrategies(data);
    setLoading(false);
  };

  useEffect(() => {
    loadStrategies();
  }, []);

  const handlePause = async (id: string) => {
    await store.pauseStrategy(id);
    toast.success("Strategy paused");
    loadStrategies();
  };

  const handleResume = async (id: string) => {
    await store.resumeStrategy(id);
    toast.success("Strategy resumed");
    loadStrategies();
  };

  const handleStop = async (id: string) => {
    await store.stopStrategy(id);
    toast.success("Strategy stopped");
    loadStrategies();
  };

  const handleClone = async (id: string) => {
    await store.cloneStrategy(id);
    toast.success("Strategy cloned");
    loadStrategies();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    await store.deleteStrategy(deleteId);
    toast.success("Strategy deleted");
    setDeleteId(null);
    loadStrategies();
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Strategies</h1>
          <p className="mt-1 text-muted-foreground">
            Manage your trading strategies
          </p>
        </div>
        <Link href="/create">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Strategy
          </Button>
        </Link>
      </div>

      {strategies.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-muted-foreground">No strategies created yet</p>
            <Link href="/create">
              <Button className="mt-4">Create your first strategy</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {strategies.map(strategy => (
            <Card
              key={strategy.id}
              className="group transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className={statusConfig[strategy.status].color}>
                        {statusConfig[strategy.status].label}
                      </Badge>
                    </div>
                    <h3 className="mt-3 truncate text-lg font-semibold">{strategy.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {store.getTemplate(strategy.templateId)?.name}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="shrink-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => router.push(`/strategies/${strategy.id}/edit`)}>
                        <Pencil className="mr-2 h-4 w-4" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleClone(strategy.id)}>
                        <Copy className="mr-2 h-4 w-4" />
                        Clone
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {strategy.status === "Deployed" && (
                        <DropdownMenuItem onClick={() => handlePause(strategy.id)}>
                          <Pause className="mr-2 h-4 w-4" />
                          Pause
                        </DropdownMenuItem>
                      )}
                      {strategy.status === "Paused" && (
                        <DropdownMenuItem onClick={() => handleResume(strategy.id)}>
                          <Play className="mr-2 h-4 w-4" />
                          Resume
                        </DropdownMenuItem>
                      )}
                      {(strategy.status === "Deployed" || strategy.status === "Paused") && (
                        <DropdownMenuItem onClick={() => handleStop(strategy.id)}>
                          <Square className="mr-2 h-4 w-4" />
                          Stop
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={() => setDeleteId(strategy.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {strategy.performanceSummary && (
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Return</p>
                      <p
                        className={cn(
                          "text-lg font-semibold",
                          strategy.performanceSummary.totalReturn >= 0
                            ? "text-success"
                            : "text-destructive"
                        )}
                      >
                        {strategy.performanceSummary.totalReturn >= 0 ? "+" : ""}
                        {strategy.performanceSummary.totalReturn.toFixed(1)}%
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Sharpe</p>
                      <p className="text-lg font-semibold">
                        {strategy.performanceSummary.sharpe.toFixed(2)}
                      </p>
                    </div>
                  </div>
                )}

                <div className="mt-4 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    Updated {new Date(strategy.updatedAt).toLocaleDateString()}
                  </span>
                  <Link href={`/strategies/${strategy.id}`}>
                    <Button variant="ghost" size="sm" className="gap-2">
                      View
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Strategy</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the strategy
              and all associated backtests.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
