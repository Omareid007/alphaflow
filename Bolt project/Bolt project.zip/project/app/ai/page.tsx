"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { store } from "@/lib/store";
import { AiEvent, FeedSource, SentimentSignal } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain,
  Zap,
  Activity,
  AlertTriangle,
  Lightbulb,
  Newspaper,
  TrendingUp,
  TrendingDown,
  Minus,
  Radio,
  Clock,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

const eventTypeConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  signal: { icon: Zap, color: "text-primary bg-primary/10", label: "Signal" },
  sentiment: { icon: Activity, color: "text-blue-400 bg-blue-400/10", label: "Sentiment" },
  news: { icon: Newspaper, color: "text-muted-foreground bg-secondary", label: "News" },
  risk: { icon: AlertTriangle, color: "text-warning bg-warning/10", label: "Risk Alert" },
  suggestion: { icon: Lightbulb, color: "text-success bg-success/10", label: "Suggestion" }
};

const feedStatusConfig: Record<string, { icon: React.ElementType; color: string }> = {
  active: { icon: CheckCircle, color: "text-success" },
  delayed: { icon: Clock, color: "text-warning" },
  offline: { icon: AlertCircle, color: "text-destructive" }
};

function EventCard({ event }: { event: AiEvent }) {
  const config = eventTypeConfig[event.type] || eventTypeConfig.signal;
  const Icon = config.icon;

  return (
    <div className="border-b border-border py-4 last:border-0">
      <div className="flex gap-4">
        <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", config.color)}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {config.label}
                </Badge>
                {event.symbol && (
                  <Badge variant="secondary" className="text-xs">
                    {event.symbol}
                  </Badge>
                )}
                {event.action && (
                  <Badge
                    variant="secondary"
                    className={cn(
                      "text-xs",
                      event.action === "BUY" ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                    )}
                  >
                    {event.action}
                  </Badge>
                )}
              </div>
              <h3 className="mt-2 font-medium">{event.headline}</h3>
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{event.explanation}</p>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground">
                {new Date(event.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {new Date(event.time).toLocaleDateString()}
              </div>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Confidence</span>
              <Progress value={event.confidence * 100} className="h-1.5 w-20" />
              <span className="text-xs font-medium">{(event.confidence * 100).toFixed(0)}%</span>
            </div>
            {event.impactedStrategies.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Impacts:</span>
                {event.impactedStrategies.map(s => (
                  <Link key={s.id} href={`/strategies/${s.id}`}>
                    <Badge variant="outline" className="text-xs hover:bg-secondary">
                      {s.name}
                    </Badge>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SentimentCard({ signal }: { signal: SentimentSignal }) {
  const normalizedScore = ((signal.score + 1) / 2) * 100;
  const TrendIcon = signal.trend === "up" ? TrendingUp : signal.trend === "down" ? TrendingDown : Minus;

  return (
    <div className="rounded-xl border border-border p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-lg font-semibold">{signal.symbol}</span>
          <TrendIcon
            className={cn(
              "h-4 w-4",
              signal.trend === "up" ? "text-success" : signal.trend === "down" ? "text-destructive" : "text-muted-foreground"
            )}
          />
        </div>
        <span
          className={cn(
            "text-lg font-semibold",
            signal.score > 0.2 ? "text-success" : signal.score < -0.2 ? "text-destructive" : "text-muted-foreground"
          )}
        >
          {signal.score > 0 ? "+" : ""}{signal.score.toFixed(2)}
        </span>
      </div>
      <div className="mt-3">
        <div className="relative h-2 w-full rounded-full bg-secondary">
          <div
            className="absolute h-2 rounded-full bg-gradient-to-r from-destructive via-muted-foreground to-success"
            style={{ width: "100%" }}
          />
          <div
            className="absolute top-1/2 h-4 w-1 -translate-y-1/2 rounded-full bg-foreground"
            style={{ left: `${normalizedScore}%` }}
          />
        </div>
        <div className="mt-1 flex justify-between text-xs text-muted-foreground">
          <span>Bearish</span>
          <span>Neutral</span>
          <span>Bullish</span>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">{signal.explanation}</p>
      <p className="mt-2 text-xs text-muted-foreground">Source: {signal.sourceName}</p>
    </div>
  );
}

export default function AiPulsePage() {
  const [events, setEvents] = useState<AiEvent[]>([]);
  const [sources, setSources] = useState<FeedSource[]>([]);
  const [sentiments, setSentiments] = useState<SentimentSignal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const eventsData = await store.getAiEvents();
      setEvents(eventsData);
      setSources(store.getFeedSources());
      setSentiments(store.getSentimentSignals());
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  const signalEvents = events.filter(e => e.type === "signal");
  const riskEvents = events.filter(e => e.type === "risk");
  const activeSources = sources.filter(s => s.status === "active").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">AI Pulse</h1>
        <p className="mt-1 text-muted-foreground">
          Real-time AI activity, signals, and market sentiment
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Sources</p>
                <p className="text-2xl font-semibold">{activeSources}/{sources.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
                <Zap className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Signals Today</p>
                <p className="text-2xl font-semibold">{signalEvents.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-warning/10">
                <AlertTriangle className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Risk Alerts</p>
                <p className="text-2xl font-semibold">{riskEvents.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-400/10">
                <Activity className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Sentiment</p>
                <p className="text-2xl font-semibold">
                  {(sentiments.reduce((sum, s) => sum + s.score, 0) / sentiments.length).toFixed(2)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Tabs defaultValue="all">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="all">All Events</TabsTrigger>
                <TabsTrigger value="signals">Signals</TabsTrigger>
                <TabsTrigger value="risk">Risk</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  {events.map(event => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="signals" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  {signalEvents.length === 0 ? (
                    <p className="py-8 text-center text-muted-foreground">No signal events</p>
                  ) : (
                    signalEvents.map(event => <EventCard key={event.id} event={event} />)
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="risk" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  {riskEvents.length === 0 ? (
                    <p className="py-8 text-center text-muted-foreground">No risk alerts</p>
                  ) : (
                    riskEvents.map(event => <EventCard key={event.id} event={event} />)
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Radio className="h-5 w-5" />
                Data Sources
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {sources.map(source => {
                const statusConfig = feedStatusConfig[source.status];
                const StatusIcon = statusConfig.icon;
                return (
                  <div key={source.id} className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
                    <div>
                      <p className="text-sm font-medium">{source.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{source.category}</p>
                    </div>
                    <StatusIcon className={cn("h-4 w-4", statusConfig.color)} />
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sentiment Gauges</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {sentiments.slice(0, 4).map(signal => (
                <SentimentCard key={signal.id} signal={signal} />
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
