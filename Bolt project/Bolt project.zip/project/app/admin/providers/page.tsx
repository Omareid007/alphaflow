"use client";

import { useEffect, useState } from "react";
import { Provider, Credential, Budget, ConnectionTestResult, UsageMetrics, ApiFunction, ApiDiscoveryResult } from "@/lib/admin/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import {
  Server,
  Plus,
  Eye,
  EyeOff,
  Key,
  DollarSign,
  TestTube,
  CheckCircle,
  XCircle,
  RotateCw,
  Search,
  Code,
  Trash2,
  Play
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { ProviderForm } from "@/components/admin/provider-form";

export default function ProvidersPage() {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null);
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [budget, setBudget] = useState<Budget | null>(null);
  const [usageMetrics, setUsageMetrics] = useState<UsageMetrics[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [credDialogOpen, setCredDialogOpen] = useState(false);
  const [budgetDialogOpen, setBudgetDialogOpen] = useState(false);
  const [discoverDialogOpen, setDiscoverDialogOpen] = useState(false);
  const [showSecret, setShowSecret] = useState<Record<string, boolean>>({});
  const [apiFunctions, setApiFunctions] = useState<ApiFunction[]>([]);
  const [discoverUrl, setDiscoverUrl] = useState('');
  const [discovering, setDiscovering] = useState(false);

  useEffect(() => {
    loadProviders();
  }, []);

  useEffect(() => {
    if (selectedProvider) {
      loadProviderDetails(selectedProvider.id);
      loadApiFunctions(selectedProvider.id);
    }
  }, [selectedProvider]);

  async function loadProviders() {
    try {
      const res = await fetch('/api/admin/providers');
      if (res.ok) {
        const data = await res.json();
        setProviders(data);
        if (data.length > 0 && !selectedProvider) {
          setSelectedProvider(data[0]);
        }
      }
    } catch (error) {
      toast.error('Failed to load providers');
    } finally {
      setLoading(false);
    }
  }

  async function loadProviderDetails(id: string) {
    try {
      const [credsRes, budgetRes, metricsRes] = await Promise.all([
        fetch(`/api/admin/providers/${id}/credentials`),
        fetch(`/api/admin/providers/${id}/budget`),
        fetch(`/api/admin/providers/${id}/usage?days=30`)
      ]);

      if (credsRes.ok) setCredentials(await credsRes.json());
      if (budgetRes.ok) setBudget(await budgetRes.json());
      if (metricsRes.ok) setUsageMetrics(await metricsRes.json());
    } catch (error) {
      console.error('Failed to load provider details:', error);
    }
  }

  async function handleCreateProvider(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    try {
      const res = await fetch('/api/admin/providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: formData.get('type'),
          name: formData.get('name'),
          baseUrl: formData.get('baseUrl') || undefined,
          status: 'active',
          tags: [],
          metadata: {}
        })
      });

      if (res.ok) {
        toast.success('Provider created');
        setCreateDialogOpen(false);
        loadProviders();
      } else {
        toast.error('Failed to create provider');
      }
    } catch (error) {
      toast.error('Failed to create provider');
    }
  }

  async function handleCreateProviderEnhanced(data: any) {
    try {
      const res = await fetch('/api/admin/providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      if (res.ok) {
        toast.success('Provider created successfully');
        setCreateDialogOpen(false);
        loadProviders();
      } else {
        const error = await res.json();
        toast.error(error.message || 'Failed to create provider');
      }
    } catch (error) {
      toast.error('Failed to create provider');
    }
  }

  async function handleTestConnection(id: string) {
    toast.loading('Testing connection...');
    try {
      const res = await fetch(`/api/admin/providers/${id}/test`, { method: 'POST' });
      if (res.ok) {
        const result: ConnectionTestResult = await res.json();
        if (result.success) {
          toast.success(`Connection successful (${result.latency}ms)`);
        } else {
          toast.error(`Connection failed: ${result.error}`);
        }
      }
    } catch (error) {
      toast.error('Test failed');
    }
  }

  async function loadApiFunctions(providerId: string) {
    try {
      const res = await fetch(`/api/admin/providers/${providerId}/functions`);
      if (res.ok) {
        const data = await res.json();
        setApiFunctions(data);
      }
    } catch (error) {
      console.error('Failed to load API functions:', error);
    }
  }

  async function handleDiscoverApis(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedProvider || !discoverUrl) return;

    setDiscovering(true);
    toast.loading('Analyzing API documentation...');

    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/discover`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentUrl: discoverUrl })
      });

      const result: ApiDiscoveryResult = await res.json();

      if (result.success) {
        toast.success(`Discovered ${result.functionsDiscovered} endpoints and ${result.schemasDiscovered} schemas`);
        setDiscoverDialogOpen(false);
        setDiscoverUrl('');
        loadApiFunctions(selectedProvider.id);
      } else {
        toast.error(result.error || 'Failed to discover APIs');
      }
    } catch (error) {
      toast.error('Failed to discover APIs');
    } finally {
      setDiscovering(false);
    }
  }

  async function handleToggleApiFunction(funcId: string, enabled: boolean) {
    if (!selectedProvider) return;

    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/functions/${funcId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isEnabled: enabled })
      });

      if (res.ok) {
        toast.success(`Endpoint ${enabled ? 'enabled' : 'disabled'}`);
        loadApiFunctions(selectedProvider.id);
      }
    } catch (error) {
      toast.error('Failed to update endpoint');
    }
  }

  async function handleTestApiFunction(funcId: string) {
    if (!selectedProvider) return;

    toast.loading('Testing endpoint...');
    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/functions/${funcId}/test`, {
        method: 'POST'
      });

      if (res.ok) {
        const result = await res.json();
        if (result.success) {
          toast.success(`Test passed (${result.latencyMs}ms)`);
        } else {
          toast.error(`Test failed: ${result.error}`);
        }
        loadApiFunctions(selectedProvider.id);
      }
    } catch (error) {
      toast.error('Test failed');
    }
  }

  async function handleDeleteApiFunction(funcId: string) {
    if (!selectedProvider) return;

    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/functions/${funcId}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        toast.success('Endpoint removed');
        loadApiFunctions(selectedProvider.id);
      }
    } catch (error) {
      toast.error('Failed to remove endpoint');
    }
  }

  async function handleAddCredential(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedProvider) return;

    const formData = new FormData(e.currentTarget);

    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/credentials`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: formData.get('kind'),
          value: formData.get('value')
        })
      });

      if (res.ok) {
        toast.success('Credential added');
        setCredDialogOpen(false);
        loadProviderDetails(selectedProvider.id);
      } else {
        toast.error('Failed to add credential');
      }
    } catch (error) {
      toast.error('Failed to add credential');
    }
  }

  async function handleUpdateBudget(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedProvider) return;

    const formData = new FormData(e.currentTarget);

    try {
      const res = await fetch(`/api/admin/providers/${selectedProvider.id}/budget`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dailyLimit: Number(formData.get('dailyLimit')),
          monthlyLimit: Number(formData.get('monthlyLimit')),
          softLimit: Number(formData.get('softLimit')),
          hardLimit: Number(formData.get('hardLimit'))
        })
      });

      if (res.ok) {
        toast.success('Budget updated');
        setBudgetDialogOpen(false);
        loadProviderDetails(selectedProvider.id);
      } else {
        toast.error('Failed to update budget');
      }
    } catch (error) {
      toast.error('Failed to update budget');
    }
  }

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Providers & Budgets</h1>
          <p className="mt-1 text-muted-foreground">
            Manage external service providers and usage limits
          </p>
        </div>
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Provider
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Provider</DialogTitle>
            </DialogHeader>
            <ProviderForm mode="create" onSubmit={handleCreateProviderEnhanced} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Providers</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {providers.map(provider => (
              <button
                key={provider.id}
                onClick={() => setSelectedProvider(provider)}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg p-3 text-left transition-colors",
                  selectedProvider?.id === provider.id
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-secondary"
                )}
              >
                <div>
                  <p className="font-medium">{provider.name}</p>
                  <p className="text-xs opacity-70">{provider.type}</p>
                </div>
                <Badge
                  variant="secondary"
                  className={
                    provider.status === 'active'
                      ? "bg-success/10 text-success"
                      : "bg-destructive/10 text-destructive"
                  }
                >
                  {provider.status}
                </Badge>
              </button>
            ))}
          </CardContent>
        </Card>

        {selectedProvider && (
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">{selectedProvider.name}</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTestConnection(selectedProvider.id)}
                  >
                    <TestTube className="mr-2 h-4 w-4" />
                    Test Connection
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => loadProviderDetails(selectedProvider.id)}
                  >
                    <RotateCw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Type</p>
                    <p className="font-medium capitalize">{selectedProvider.type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge className={
                      selectedProvider.status === 'active' ? 'bg-success/10 text-success' :
                      selectedProvider.status === 'error' ? 'bg-destructive/10 text-destructive' :
                      'bg-warning/10 text-warning'
                    }>
                      {selectedProvider.status}
                    </Badge>
                  </div>
                  <div className="md:col-span-2">
                    <p className="text-sm text-muted-foreground">Base URL</p>
                    <p className="font-medium break-all">{selectedProvider.baseUrl || 'Not set'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">API Version</p>
                    <p className="font-medium">{selectedProvider.apiVersion || 'Not specified'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Auth Method</p>
                    <p className="font-medium capitalize">{selectedProvider.authMethod || 'header'}</p>
                  </div>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <h4 className="font-medium text-sm">Rate Limiting</h4>
                  <div className="grid gap-4 md:grid-cols-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Max Requests</p>
                      <p className="font-medium">{selectedProvider.rateLimitRequests || 100}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Time Window</p>
                      <p className="font-medium">{selectedProvider.rateLimitWindowSeconds || 60}s</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Per Key</p>
                      <p className="font-medium">{selectedProvider.rateLimitPerKey ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <h4 className="font-medium text-sm">Retry Policy</h4>
                  <div className="grid gap-4 md:grid-cols-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Enabled</p>
                      <p className="font-medium">{selectedProvider.retryEnabled ? 'Yes' : 'No'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Max Attempts</p>
                      <p className="font-medium">{selectedProvider.retryMaxAttempts || 3}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Backoff</p>
                      <p className="font-medium">{selectedProvider.retryBackoffMs || 1000}ms × {selectedProvider.retryBackoffMultiplier || 2}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <h4 className="font-medium text-sm">Timeouts</h4>
                  <div className="grid gap-4 md:grid-cols-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Connect</p>
                      <p className="font-medium">{selectedProvider.timeoutConnectMs || 5000}ms</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Request</p>
                      <p className="font-medium">{selectedProvider.timeoutRequestMs || 30000}ms</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total</p>
                      <p className="font-medium">{selectedProvider.timeoutTotalMs || 60000}ms</p>
                    </div>
                  </div>
                </div>

                {selectedProvider.healthCheckEnabled && (
                  <div className="space-y-3 border-t pt-4">
                    <h4 className="font-medium text-sm">Health Check</h4>
                    <div className="grid gap-4 md:grid-cols-3 text-sm">
                      <div>
                        <p className="text-muted-foreground">Endpoint</p>
                        <p className="font-medium">{selectedProvider.healthCheckEndpoint || '/health'}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Interval</p>
                        <p className="font-medium">{selectedProvider.healthCheckIntervalSeconds || 300}s</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Last Check</p>
                        <p className="font-medium">{selectedProvider.lastHealthCheck ? new Date(selectedProvider.lastHealthCheck).toLocaleString() : 'Never'}</p>
                      </div>
                    </div>
                  </div>
                )}

                {selectedProvider.tags && selectedProvider.tags.length > 0 && (
                  <div className="space-y-2 border-t pt-4">
                    <h4 className="font-medium text-sm">Tags</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProvider.tags.map((tag: string) => (
                        <Badge key={tag} variant="outline">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Key className="h-4 w-4" />
                  Credentials
                </CardTitle>
                <Dialog open={credDialogOpen} onOpenChange={setCredDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Add
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Credential</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddCredential} className="space-y-4">
                      <div>
                        <Label>Type</Label>
                        <Select name="kind" required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="apiKey">API Key</SelectItem>
                            <SelectItem value="oauth">OAuth</SelectItem>
                            <SelectItem value="token">Token</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Value</Label>
                        <Input name="value" type="password" required />
                      </div>
                      <Button type="submit" className="w-full">Add Credential</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {credentials.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">No credentials</p>
                ) : (
                  <div className="space-y-2">
                    {credentials.map(cred => (
                      <div key={cred.id} className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
                        <div>
                          <p className="text-sm font-medium">{cred.kind}</p>
                          <p className="text-xs text-muted-foreground">
                            {showSecret[cred.id] ? cred.encryptedValue.slice(0, 20) + '...' : '••••••••••••'}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setShowSecret(prev => ({ ...prev, [cred.id]: !prev[cred.id] }))}
                        >
                          {showSecret[cred.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <DollarSign className="h-4 w-4" />
                  Budget
                </CardTitle>
                <Dialog open={budgetDialogOpen} onOpenChange={setBudgetDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">Configure</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Configure Budget</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleUpdateBudget} className="space-y-4">
                      <div>
                        <Label>Daily Limit ($)</Label>
                        <Input name="dailyLimit" type="number" step="0.01" defaultValue={budget?.dailyLimit || 0} required />
                      </div>
                      <div>
                        <Label>Monthly Limit ($)</Label>
                        <Input name="monthlyLimit" type="number" step="0.01" defaultValue={budget?.monthlyLimit || 0} required />
                      </div>
                      <div>
                        <Label>Soft Limit ($)</Label>
                        <Input name="softLimit" type="number" step="0.01" defaultValue={budget?.softLimit || 0} required />
                      </div>
                      <div>
                        <Label>Hard Limit ($)</Label>
                        <Input name="hardLimit" type="number" step="0.01" defaultValue={budget?.hardLimit || 0} required />
                      </div>
                      <Button type="submit" className="w-full">Update Budget</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent className="space-y-4">
                {budget && (
                  <>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="rounded-lg bg-secondary/50 p-3">
                        <p className="text-sm text-muted-foreground">Daily Usage</p>
                        <p className="text-2xl font-semibold">${budget.usageToday.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">of ${budget.dailyLimit.toFixed(2)} limit</p>
                      </div>
                      <div className="rounded-lg bg-secondary/50 p-3">
                        <p className="text-sm text-muted-foreground">Monthly Usage</p>
                        <p className="text-2xl font-semibold">${budget.usageMonth.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">of ${budget.monthlyLimit.toFixed(2)} limit</p>
                      </div>
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={usageMetrics}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis
                            dataKey="date"
                            tickFormatter={d => new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                          />
                          <YAxis tickFormatter={v => `$${v}`} />
                          <Tooltip
                            content={({ active, payload }) => {
                              if (!active || !payload?.length) return null;
                              return (
                                <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                                  <p className="text-sm text-muted-foreground">
                                    {new Date(payload[0].payload.date).toLocaleDateString()}
                                  </p>
                                  <p className="font-semibold">${Number(payload[0].value).toFixed(2)}</p>
                                </div>
                              );
                            }}
                          />
                          <Line
                            type="monotone"
                            dataKey="amount"
                            stroke="hsl(var(--primary))"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Code className="h-4 w-4" />
                  API Functions
                </CardTitle>
                <Dialog open={discoverDialogOpen} onOpenChange={setDiscoverDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Search className="mr-2 h-4 w-4" />
                      Discover APIs
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Discover API Functions</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleDiscoverApis} className="space-y-4">
                      <div className="space-y-2">
                        <Label>API Documentation URL</Label>
                        <Input
                          value={discoverUrl}
                          onChange={(e) => setDiscoverUrl(e.target.value)}
                          placeholder="https://api.example.com/openapi.json"
                          type="url"
                          required
                        />
                        <p className="text-xs text-muted-foreground">
                          Enter the URL to an OpenAPI/Swagger specification (JSON or YAML)
                        </p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Supported formats:</p>
                        <ul className="text-xs text-muted-foreground space-y-1">
                          <li>- OpenAPI 3.x (openapi.json, openapi.yaml)</li>
                          <li>- Swagger 2.0 (swagger.json, swagger.yaml)</li>
                          <li>- Direct API spec URLs from providers</li>
                        </ul>
                      </div>
                      <Button type="submit" className="w-full" disabled={discovering}>
                        {discovering ? 'Analyzing...' : 'Discover APIs'}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {apiFunctions.length === 0 ? (
                  <div className="text-center py-8">
                    <Code className="mx-auto h-12 w-12 text-muted-foreground/50" />
                    <p className="mt-4 text-muted-foreground">No API functions discovered yet</p>
                    <p className="text-sm text-muted-foreground">Click "Discover APIs" to analyze the provider's API documentation</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
                      <span>{apiFunctions.length} endpoints discovered</span>
                      <span>{apiFunctions.filter(f => f.isEnabled).length} enabled</span>
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-20">Method</TableHead>
                          <TableHead>Endpoint</TableHead>
                          <TableHead className="w-24">Status</TableHead>
                          <TableHead className="w-20">Enabled</TableHead>
                          <TableHead className="w-32">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {apiFunctions.map(func => (
                          <TableRow key={func.id}>
                            <TableCell>
                              <Badge variant="outline" className={cn(
                                func.method === 'GET' && 'bg-blue-500/10 text-blue-500',
                                func.method === 'POST' && 'bg-green-500/10 text-green-500',
                                func.method === 'PUT' && 'bg-yellow-500/10 text-yellow-500',
                                func.method === 'PATCH' && 'bg-orange-500/10 text-orange-500',
                                func.method === 'DELETE' && 'bg-red-500/10 text-red-500'
                              )}>
                                {func.method}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-mono text-sm">{func.path}</p>
                                {func.summary && (
                                  <p className="text-xs text-muted-foreground mt-1">{func.summary}</p>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              {func.lastTestSuccess === true && (
                                <Badge variant="outline" className="bg-success/10 text-success">
                                  <CheckCircle className="mr-1 h-3 w-3" />
                                  OK
                                </Badge>
                              )}
                              {func.lastTestSuccess === false && (
                                <Badge variant="outline" className="bg-destructive/10 text-destructive">
                                  <XCircle className="mr-1 h-3 w-3" />
                                  Failed
                                </Badge>
                              )}
                              {func.lastTestSuccess === null && (
                                <span className="text-xs text-muted-foreground">Not tested</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Switch
                                checked={func.isEnabled}
                                onCheckedChange={(checked) => handleToggleApiFunction(func.id, checked)}
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleTestApiFunction(func.id)}
                                  title="Test endpoint"
                                >
                                  <Play className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteApiFunction(func.id)}
                                  title="Remove endpoint"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
