"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { List } from "lucide-react";

export default function AdminStrategiesPage() {
  const strategies = [
    { name: 'Alpha Momentum', user: 'user@example.com', status: 'Deployed', pnl: 1250 },
    { name: 'Beta Reversion', user: 'user@example.com', status: 'Backtested', pnl: 0 },
    { name: 'Gamma Pairs', user: 'admin@example.com', status: 'Paused', pnl: -120 }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Strategies (Admin)</h1>
        <p className="mt-1 text-muted-foreground">Global strategy management</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <List className="h-5 w-5" />
            All Strategies
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {strategies.map(strat => (
              <div key={strat.name} className="flex items-center justify-between rounded-lg border border-border p-3">
                <div>
                  <p className="font-medium">{strat.name}</p>
                  <p className="text-xs text-muted-foreground">{strat.user}</p>
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary">{strat.status}</Badge>
                  <span className={strat.pnl >= 0 ? 'text-success' : 'text-destructive'}>
                    {strat.pnl >= 0 ? '+' : ''}${strat.pnl}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
