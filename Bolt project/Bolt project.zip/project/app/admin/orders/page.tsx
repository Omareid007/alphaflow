"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ShoppingCart } from "lucide-react";

export default function OrdersPage() {
  const mockOrders = [
    { id: '1', symbol: 'AAPL', side: 'buy', qty: 100, price: 178.5, status: 'filled', strategy: 'Alpha Momentum' },
    { id: '2', symbol: 'GOOGL', side: 'sell', qty: 50, price: 141.8, status: 'filled', strategy: 'Beta Reversion' },
    { id: '3', symbol: 'MSFT', side: 'buy', qty: 75, price: 378.9, status: 'pending', strategy: 'Alpha Momentum' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Orders</h1>
        <p className="mt-1 text-muted-foreground">Admin view of all order activity</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Order History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Side</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Strategy</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockOrders.map(order => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.symbol}</TableCell>
                  <TableCell>
                    <Badge variant={order.side === 'buy' ? 'default' : 'secondary'}>
                      {order.side.toUpperCase()}
                    </Badge>
                  </TableCell>
                  <TableCell>{order.qty}</TableCell>
                  <TableCell>${order.price}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={order.status === 'filled' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}>
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{order.strategy}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
