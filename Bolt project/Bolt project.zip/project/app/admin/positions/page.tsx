"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Layers } from "lucide-react";
import { cn } from "@/lib/utils";

export default function PositionsPage() {
  const mockPositions = [
    { symbol: 'AAPL', qty: 100, avgPrice: 175.2, currentPrice: 178.5, pnl: 330, strategy: 'Alpha Momentum' },
    { symbol: 'GOOGL', qty: -50, avgPrice: 143.1, currentPrice: 141.8, pnl: 65, strategy: 'Beta Reversion' },
    { symbol: 'MSFT', qty: 75, avgPrice: 380.5, currentPrice: 378.9, pnl: -120, strategy: 'Alpha Momentum' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Positions</h1>
        <p className="mt-1 text-muted-foreground">Active positions across all strategies</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layers className="h-5 w-5" />
            Current Positions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Avg Price</TableHead>
                <TableHead>Current Price</TableHead>
                <TableHead>Unrealized P&L</TableHead>
                <TableHead>Strategy</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockPositions.map(pos => (
                <TableRow key={pos.symbol}>
                  <TableCell className="font-medium">{pos.symbol}</TableCell>
                  <TableCell>{pos.qty > 0 ? `+${pos.qty}` : pos.qty}</TableCell>
                  <TableCell>${pos.avgPrice}</TableCell>
                  <TableCell>${pos.currentPrice}</TableCell>
                  <TableCell className={cn(pos.pnl >= 0 ? 'text-success' : 'text-destructive')}>
                    {pos.pnl >= 0 ? '+' : ''}${pos.pnl}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{pos.strategy}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
