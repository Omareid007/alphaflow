"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { store } from "@/lib/store";
import { AlgorithmTemplate, Preset, BacktestRun, Strategy } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { WizardField } from "./wizard-field";
import { BacktestResults } from "./backtest-results";
import {
  TrendingUp,
  Activity,
  GitCompare,
  Brain,
  ChevronLeft,
  ChevronRight,
  Check,
  Play,
  Rocket,
  Settings2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const templateIcons: Record<string, React.ElementType> = {
  TrendingUp,
  Activity,
  GitCompare,
  Brain
};

interface StrategyWizardProps {
  existingStrategy?: Strategy;
  existingBacktest?: BacktestRun;
}

export function StrategyWizard({ existingStrategy, existingBacktest }: StrategyWizardProps) {
  const router = useRouter();
  const [templates] = useState<AlgorithmTemplate[]>(() => store.getTemplates());
  const [selectedTemplate, setSelectedTemplate] = useState<AlgorithmTemplate | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<Preset | null>(null);
  const [configValues, setConfigValues] = useState<Record<string, string | number | boolean | string[]>>({});
  const [currentStep, setCurrentStep] = useState(0);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [strategyName, setStrategyName] = useState("");
  const [backtestProgress, setBacktestProgress] = useState(0);
  const [isBacktesting, setIsBacktesting] = useState(false);
  const [backtest, setBacktest] = useState<BacktestRun | null>(existingBacktest || null);
  const [strategy, setStrategy] = useState<Strategy | null>(existingStrategy || null);

  useEffect(() => {
    if (existingStrategy) {
      const template = templates.find(t => t.id === existingStrategy.templateId);
      if (template) {
        setSelectedTemplate(template);
        setConfigValues(existingStrategy.configValues);
        setStrategyName(existingStrategy.name);
        setCurrentStep(1);
      }
    }
  }, [existingStrategy, templates]);

  const initializeConfig = useCallback((template: AlgorithmTemplate) => {
    const defaults: Record<string, string | number | boolean | string[]> = {};
    template.stepSchema.steps.forEach(step => {
      step.fields.forEach(field => {
        defaults[field.key] = field.default;
      });
      step.advancedFields?.forEach(field => {
        defaults[field.key] = field.default;
      });
    });
    return defaults;
  }, []);

  const handleTemplateSelect = (template: AlgorithmTemplate) => {
    setSelectedTemplate(template);
    setConfigValues(initializeConfig(template));
    setStrategyName(`My ${template.name}`);
    setCurrentStep(1);
  };

  const handlePresetSelect = (preset: Preset) => {
    setSelectedPreset(preset);
    if (preset.name !== "Custom") {
      setConfigValues(prev => ({ ...prev, ...preset.valuesByFieldKey }));
    }
  };

  const handleFieldChange = (key: string, value: string | number | boolean | string[]) => {
    setConfigValues(prev => ({ ...prev, [key]: value }));
    if (selectedPreset?.name !== "Custom") {
      const customPreset = selectedTemplate?.presets.find(p => p.name === "Custom");
      if (customPreset) setSelectedPreset(customPreset);
    }
  };

  const handleRunBacktest = async () => {
    if (!selectedTemplate) return;

    setIsBacktesting(true);
    setBacktestProgress(0);

    try {
      let currentStrategy = strategy;

      if (!currentStrategy) {
        currentStrategy = await store.createStrategy({
          name: strategyName,
          templateId: selectedTemplate.id,
          status: "Draft",
          configValues
        });
        setStrategy(currentStrategy);
      } else {
        await store.updateStrategy(currentStrategy.id, { configValues, name: strategyName });
      }

      const result = await store.runBacktest(currentStrategy.id, setBacktestProgress);
      setBacktest(result);
      toast.success("Backtest completed");
    } catch (error) {
      toast.error("Backtest failed");
    } finally {
      setIsBacktesting(false);
    }
  };

  const handleApplySuggestions = () => {
    if (!backtest?.interpretation.suggestedEdits.length) return;

    const updates: Record<string, string | number | boolean | string[]> = {};
    backtest.interpretation.suggestedEdits.forEach(edit => {
      updates[edit.fieldKey] = edit.suggestedValue;
    });

    setConfigValues(prev => ({ ...prev, ...updates }));
    setBacktest(null);
    toast.success("Suggestions applied - run backtest again to see results");
  };

  const handleDeploy = async (mode: "paper" | "live") => {
    if (!strategy) return;

    try {
      await store.deployStrategy(strategy.id, mode);
      toast.success(`Strategy deployed to ${mode} trading`);
      router.push("/strategies");
    } catch (error) {
      toast.error("Deployment failed");
    }
  };

  const totalSteps = selectedTemplate ? selectedTemplate.stepSchema.steps.length : 0;

  if (!selectedTemplate) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Choose Algorithm Template</h2>
          <p className="mt-1 text-muted-foreground">
            Select a trading algorithm to start building your strategy
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {templates.map(template => {
            const Icon = templateIcons[template.icon] || TrendingUp;
            return (
              <Card
                key={template.id}
                className={cn(
                  "cursor-pointer transition-all hover:border-primary hover:shadow-lg",
                  "hover:shadow-primary/5"
                )}
                onClick={() => handleTemplateSelect(template)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{template.name}</h3>
                        <Badge variant="outline" className="text-xs">
                          {template.difficulty}
                        </Badge>
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                        {template.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  const currentStepData = selectedTemplate.stepSchema.steps[currentStep - 1];
  const isConfigStep = currentStep >= 1 && currentStep <= totalSteps;
  const isBacktestStep = currentStep === totalSteps + 1;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">{strategyName}</h2>
          <p className="mt-1 text-muted-foreground">
            {selectedTemplate.name} Strategy
          </p>
        </div>
        <div className="flex items-center gap-2">
          {Array.from({ length: totalSteps + 2 }, (_, i) => (
            <div
              key={i}
              className={cn(
                "h-2 w-8 rounded-full transition-colors",
                i < currentStep ? "bg-primary" : "bg-secondary"
              )}
            />
          ))}
        </div>
      </div>

      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Choose a Preset</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {selectedTemplate.presets.map(preset => (
                <button
                  key={preset.id}
                  onClick={() => handlePresetSelect(preset)}
                  className={cn(
                    "rounded-xl border-2 p-4 text-left transition-all",
                    selectedPreset?.id === preset.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{preset.name}</span>
                    {selectedPreset?.id === preset.id && (
                      <Check className="h-4 w-4 text-primary" />
                    )}
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {preset.description}
                  </p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {isConfigStep && currentStepData && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">{currentStepData.title}</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                {currentStepData.description}
              </p>
            </div>
            {currentStepData.advancedFields && currentStepData.advancedFields.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAdvanced(!showAdvanced)}
              >
                <Settings2 className="mr-2 h-4 w-4" />
                {showAdvanced ? "Hide" : "Show"} Advanced
              </Button>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              {currentStepData.fields.map(field => (
                <WizardField
                  key={field.key}
                  field={field}
                  value={configValues[field.key]}
                  onChange={value => handleFieldChange(field.key, value)}
                />
              ))}
            </div>

            {showAdvanced && currentStepData.advancedFields && (
              <div className="border-t border-border pt-6">
                <h4 className="mb-4 text-sm font-medium text-muted-foreground">
                  Advanced Settings
                </h4>
                <div className="grid gap-6 md:grid-cols-2">
                  {currentStepData.advancedFields.map(field => (
                    <WizardField
                      key={field.key}
                      field={field}
                      value={configValues[field.key]}
                      onChange={value => handleFieldChange(field.key, value)}
                    />
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {isBacktestStep && !isBacktesting && !backtest && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                <Play className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mt-4 text-xl font-semibold">Ready to Backtest</h3>
              <p className="mx-auto mt-2 max-w-md text-muted-foreground">
                Your strategy is configured. Run a backtest to see historical performance
                and get AI-powered insights.
              </p>
              <div className="mt-2 mb-6">
                <input
                  type="text"
                  value={strategyName}
                  onChange={e => setStrategyName(e.target.value)}
                  className="mx-auto block w-full max-w-xs rounded-lg border border-border bg-background px-4 py-2 text-center"
                  placeholder="Strategy Name"
                />
              </div>
              <Button size="lg" onClick={handleRunBacktest}>
                <Play className="mr-2 h-5 w-5" />
                Run Backtest
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {isBacktesting && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <h3 className="mt-4 text-xl font-semibold">Running Backtest</h3>
              <p className="mt-2 text-muted-foreground">
                Simulating your strategy across historical data...
              </p>
              <Progress value={backtestProgress} className="mx-auto mt-6 max-w-sm" />
              <p className="mt-2 text-sm text-muted-foreground">{backtestProgress}%</p>
            </div>
          </CardContent>
        </Card>
      )}

      {backtest && (
        <BacktestResults
          backtest={backtest}
          onApplySuggestions={handleApplySuggestions}
          onRunAgain={() => setBacktest(null)}
          onDeploy={handleDeploy}
        />
      )}

      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={() => {
            if (currentStep === 1) {
              setSelectedTemplate(null);
              setSelectedPreset(null);
              setBacktest(null);
            } else if (backtest) {
              setBacktest(null);
            } else {
              setCurrentStep(prev => prev - 1);
            }
          }}
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        {!backtest && currentStep <= totalSteps && (
          <Button onClick={() => setCurrentStep(prev => prev + 1)}>
            {currentStep === totalSteps ? "Review & Backtest" : "Continue"}
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}
