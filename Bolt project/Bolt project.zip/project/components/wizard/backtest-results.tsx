"use client";

import { BacktestRun } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Lightbulb,
  Play,
  Rocket,
  RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";

interface BacktestResultsProps {
  backtest: BacktestRun;
  onApplySuggestions: () => void;
  onRunAgain: () => void;
  onDeploy: (mode: "paper" | "live") => void;
}

function MetricTile({
  label,
  value,
  format = "number",
  good = true
}: {
  label: string;
  value: number;
  format?: "percent" | "number" | "ratio";
  good?: boolean;
}) {
  let formatted: string;
  if (format === "percent") {
    formatted = `${value.toFixed(1)}%`;
  } else if (format === "ratio") {
    formatted = value.toFixed(2);
  } else {
    formatted = value.toFixed(0);
  }

  return (
    <div className="rounded-xl bg-secondary/50 p-4">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p
        className={cn(
          "mt-1 text-2xl font-semibold",
          format === "percent" && (good ? "text-success" : "text-destructive")
        )}
      >
        {formatted}
      </p>
    </div>
  );
}

export function BacktestResults({
  backtest,
  onApplySuggestions,
  onRunAgain,
  onDeploy
}: BacktestResultsProps) {
  const { metrics, chartSeries, interpretation } = backtest;

  const isGoodPerformance = metrics.sharpe > 1 && metrics.maxDrawdown < 20;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Backtest Results</CardTitle>
            <Badge
              variant={isGoodPerformance ? "default" : "secondary"}
              className={isGoodPerformance ? "bg-success" : ""}
            >
              {isGoodPerformance ? "Strong Performance" : "Review Recommended"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-6">
            <MetricTile
              label="CAGR"
              value={metrics.cagr}
              format="percent"
              good={metrics.cagr > 0}
            />
            <MetricTile label="Sharpe" value={metrics.sharpe} format="ratio" />
            <MetricTile
              label="Max Drawdown"
              value={metrics.maxDrawdown}
              format="percent"
              good={metrics.maxDrawdown < 20}
            />
            <MetricTile label="Volatility" value={metrics.volatility} format="percent" />
            <MetricTile label="Win Rate" value={metrics.winRate} format="percent" />
            <MetricTile label="Total Trades" value={metrics.totalTrades} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Performance Charts</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="equity">
            <TabsList>
              <TabsTrigger value="equity">Equity Curve</TabsTrigger>
              <TabsTrigger value="drawdown">Drawdown</TabsTrigger>
              <TabsTrigger value="returns">Returns</TabsTrigger>
            </TabsList>

            <TabsContent value="equity" className="mt-4">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartSeries.equityCurve}>
                    <defs>
                      <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="date"
                      tickFormatter={d => new Date(d).toLocaleDateString("en-US", { month: "short" })}
                    />
                    <YAxis
                      tickFormatter={v => `$${(v / 1000).toFixed(0)}k`}
                      domain={["dataMin - 5000", "dataMax + 5000"]}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        return (
                          <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                            <p className="text-sm text-muted-foreground">
                              {new Date(payload[0].payload.date).toLocaleDateString()}
                            </p>
                            <p className="text-lg font-semibold">
                              ${payload[0].value?.toLocaleString()}
                            </p>
                          </div>
                        );
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      fill="url(#equityGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            <TabsContent value="drawdown" className="mt-4">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartSeries.drawdown}>
                    <defs>
                      <linearGradient id="ddGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="date"
                      tickFormatter={d => new Date(d).toLocaleDateString("en-US", { month: "short" })}
                    />
                    <YAxis tickFormatter={v => `${v}%`} domain={["dataMin - 5", 0]} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        return (
                          <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                            <p className="text-sm text-muted-foreground">
                              {new Date(payload[0].payload.date).toLocaleDateString()}
                            </p>
                            <p className="text-lg font-semibold text-destructive">
                              {Number(payload[0].value).toFixed(2)}%
                            </p>
                          </div>
                        );
                      }}
                    />
                    <ReferenceLine y={-metrics.maxDrawdown} stroke="hsl(var(--destructive))" strokeDasharray="5 5" />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(var(--destructive))"
                      strokeWidth={2}
                      fill="url(#ddGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            <TabsContent value="returns" className="mt-4">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartSeries.returns.filter((_, i) => i % 5 === 0)}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="date"
                      tickFormatter={d => new Date(d).toLocaleDateString("en-US", { month: "short" })}
                    />
                    <YAxis tickFormatter={v => `${v}%`} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        const value = Number(payload[0].value);
                        return (
                          <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                            <p className="text-sm text-muted-foreground">
                              {new Date(payload[0].payload.date).toLocaleDateString()}
                            </p>
                            <p className={cn("text-lg font-semibold", value >= 0 ? "text-success" : "text-destructive")}>
                              {value >= 0 ? "+" : ""}{value.toFixed(2)}%
                            </p>
                          </div>
                        );
                      }}
                    />
                    <ReferenceLine y={0} stroke="hsl(var(--border))" />
                    <Bar
                      dataKey="value"
                      fill="hsl(var(--primary))"
                      radius={[2, 2, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Lightbulb className="h-5 w-5 text-primary" />
            AI Interpretation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-muted-foreground">{interpretation.summary}</p>

          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h4 className="mb-3 flex items-center gap-2 font-medium">
                <CheckCircle className="h-4 w-4 text-success" />
                Strengths
              </h4>
              <ul className="space-y-2">
                {interpretation.strengths.map((strength, i) => (
                  <li key={i} className="text-sm text-muted-foreground">
                    {strength}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="mb-3 flex items-center gap-2 font-medium">
                <AlertTriangle className="h-4 w-4 text-warning" />
                Risks
              </h4>
              <ul className="space-y-2">
                {interpretation.risks.map((risk, i) => (
                  <li key={i} className="text-sm text-muted-foreground">
                    {risk}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {interpretation.suggestedEdits.length > 0 && (
            <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
              <h4 className="mb-3 font-medium">Suggested Optimizations</h4>
              <div className="space-y-3">
                {interpretation.suggestedEdits.map((edit, i) => (
                  <div key={i} className="flex items-start gap-3 text-sm">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                      {i + 1}
                    </div>
                    <div>
                      <p className="text-muted-foreground">
                        Change <span className="font-medium text-foreground">{edit.fieldKey}</span>{" "}
                        from {String(edit.currentValue)} to{" "}
                        <span className="font-medium text-primary">{String(edit.suggestedValue)}</span>
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">{edit.rationale}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button className="mt-4" variant="outline" onClick={onApplySuggestions}>
                Apply Suggestions
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex gap-3">
              <Button variant="outline" onClick={onRunAgain}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Modify & Retest
              </Button>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => onDeploy("paper")}>
                <Play className="mr-2 h-4 w-4" />
                Deploy Paper
              </Button>
              <Button onClick={() => onDeploy("live")}>
                <Rocket className="mr-2 h-4 w-4" />
                Deploy Live
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
