"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

interface ProviderFormProps {
  onSubmit: (data: any) => void;
  initialData?: any;
  mode: 'create' | 'edit';
}

export function ProviderForm({ onSubmit, initialData, mode }: ProviderFormProps) {
  const [formData, setFormData] = useState(initialData || {
    name: '',
    type: 'data',
    baseUrl: '',
    apiVersion: '',
    authMethod: 'header',
    status: 'active',
    rateLimitRequests: 100,
    rateLimitWindowSeconds: 60,
    rateLimitPerKey: false,
    retryEnabled: true,
    retryMaxAttempts: 3,
    retryBackoffMs: 1000,
    retryBackoffMultiplier: 2.0,
    timeoutConnectMs: 5000,
    timeoutRequestMs: 30000,
    timeoutTotalMs: 60000,
    healthCheckEnabled: true,
    healthCheckEndpoint: '/health',
    healthCheckIntervalSeconds: 300,
    healthCheckTimeoutMs: 5000,
    connectionPoolSize: 10,
    connectionPoolTimeoutMs: 30000,
    webhookUrl: '',
    webhookSecret: '',
    webhookEvents: [],
    requestFormat: 'json',
    responseFormat: 'json',
    customHeaders: {},
    tags: [],
    metadata: {}
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const updateField = (field: string, value: any) => {
    setFormData((prev: any) => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">Basic</TabsTrigger>
          <TabsTrigger value="auth">Auth</TabsTrigger>
          <TabsTrigger value="limits">Limits</TabsTrigger>
          <TabsTrigger value="reliability">Reliability</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-4 mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Provider Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="e.g. OpenAI GPT-4"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <Select value={formData.type} onValueChange={(value) => updateField('type', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="data">Data Provider</SelectItem>
                  <SelectItem value="llm">LLM Provider</SelectItem>
                  <SelectItem value="broker">Broker</SelectItem>
                  <SelectItem value="news">News Feed</SelectItem>
                  <SelectItem value="sentiment">Sentiment Analysis</SelectItem>
                  <SelectItem value="analytics">Analytics</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="baseUrl">Base URL *</Label>
              <Input
                id="baseUrl"
                type="url"
                value={formData.baseUrl}
                onChange={(e) => updateField('baseUrl', e.target.value)}
                placeholder="https://api.provider.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="apiVersion">API Version</Label>
              <Input
                id="apiVersion"
                value={formData.apiVersion}
                onChange={(e) => updateField('apiVersion', e.target.value)}
                placeholder="v1, 2024-01, etc."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="requestFormat">Request Format</Label>
              <Select value={formData.requestFormat} onValueChange={(value) => updateField('requestFormat', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="xml">XML</SelectItem>
                  <SelectItem value="form">Form Data</SelectItem>
                  <SelectItem value="graphql">GraphQL</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="responseFormat">Response Format</Label>
              <Select value={formData.responseFormat} onValueChange={(value) => updateField('responseFormat', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="xml">XML</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="text">Plain Text</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={formData.tags.join(', ')}
              onChange={(e) => updateField('tags', e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean))}
              placeholder="production, high-priority, ml"
            />
          </div>
        </TabsContent>

        <TabsContent value="auth" className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="authMethod">Authentication Method</Label>
            <Select value={formData.authMethod} onValueChange={(value) => updateField('authMethod', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="header">Header (API Key)</SelectItem>
                <SelectItem value="bearer">Bearer Token</SelectItem>
                <SelectItem value="basic">Basic Auth</SelectItem>
                <SelectItem value="oauth2">OAuth 2.0</SelectItem>
                <SelectItem value="query">Query Parameter</SelectItem>
                <SelectItem value="body">Request Body</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="customHeaders">Custom Headers (JSON)</Label>
            <Textarea
              id="customHeaders"
              value={JSON.stringify(formData.customHeaders, null, 2)}
              onChange={(e) => {
                try {
                  updateField('customHeaders', JSON.parse(e.target.value));
                } catch {}
              }}
              placeholder='{"X-Custom-Header": "value"}'
              rows={4}
            />
            <p className="text-xs text-muted-foreground">JSON object with custom header key-value pairs</p>
          </div>
        </TabsContent>

        <TabsContent value="limits" className="space-y-4 mt-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Rate Limiting</Label>
                <p className="text-sm text-muted-foreground">Control request rate to prevent overload</p>
              </div>
              <Switch
                checked={formData.rateLimitRequests > 0}
                onCheckedChange={(checked) => updateField('rateLimitRequests', checked ? 100 : 0)}
              />
            </div>

            {formData.rateLimitRequests > 0 && (
              <div className="grid gap-4 md:grid-cols-2 pl-6">
                <div className="space-y-2">
                  <Label htmlFor="rateLimitRequests">Max Requests</Label>
                  <Input
                    id="rateLimitRequests"
                    type="number"
                    value={formData.rateLimitRequests}
                    onChange={(e) => updateField('rateLimitRequests', parseInt(e.target.value))}
                    min="1"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rateLimitWindowSeconds">Time Window (seconds)</Label>
                  <Input
                    id="rateLimitWindowSeconds"
                    type="number"
                    value={formData.rateLimitWindowSeconds}
                    onChange={(e) => updateField('rateLimitWindowSeconds', parseInt(e.target.value))}
                    min="1"
                  />
                </div>
                <div className="flex items-center space-x-2 md:col-span-2">
                  <Switch
                    checked={formData.rateLimitPerKey}
                    onCheckedChange={(checked) => updateField('rateLimitPerKey', checked)}
                  />
                  <Label>Apply rate limit per API key</Label>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-medium">Connection Pool</h4>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="connectionPoolSize">Pool Size</Label>
                <Input
                  id="connectionPoolSize"
                  type="number"
                  value={formData.connectionPoolSize}
                  onChange={(e) => updateField('connectionPoolSize', parseInt(e.target.value))}
                  min="1"
                  max="1000"
                />
                <p className="text-xs text-muted-foreground">Max concurrent connections</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="connectionPoolTimeoutMs">Pool Timeout (ms)</Label>
                <Input
                  id="connectionPoolTimeoutMs"
                  type="number"
                  value={formData.connectionPoolTimeoutMs}
                  onChange={(e) => updateField('connectionPoolTimeoutMs', parseInt(e.target.value))}
                  min="1000"
                />
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="reliability" className="space-y-4 mt-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Retry Policy</Label>
                <p className="text-sm text-muted-foreground">Automatically retry failed requests</p>
              </div>
              <Switch
                checked={formData.retryEnabled}
                onCheckedChange={(checked) => updateField('retryEnabled', checked)}
              />
            </div>

            {formData.retryEnabled && (
              <div className="grid gap-4 md:grid-cols-2 pl-6">
                <div className="space-y-2">
                  <Label htmlFor="retryMaxAttempts">Max Attempts</Label>
                  <Input
                    id="retryMaxAttempts"
                    type="number"
                    value={formData.retryMaxAttempts}
                    onChange={(e) => updateField('retryMaxAttempts', parseInt(e.target.value))}
                    min="1"
                    max="10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="retryBackoffMs">Initial Backoff (ms)</Label>
                  <Input
                    id="retryBackoffMs"
                    type="number"
                    value={formData.retryBackoffMs}
                    onChange={(e) => updateField('retryBackoffMs', parseInt(e.target.value))}
                    min="100"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="retryBackoffMultiplier">Backoff Multiplier</Label>
                  <Input
                    id="retryBackoffMultiplier"
                    type="number"
                    step="0.1"
                    value={formData.retryBackoffMultiplier}
                    onChange={(e) => updateField('retryBackoffMultiplier', parseFloat(e.target.value))}
                    min="1"
                    max="10"
                  />
                  <p className="text-xs text-muted-foreground">Exponential backoff factor (e.g., 2.0 doubles wait time)</p>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-medium">Timeout Configuration</h4>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="timeoutConnectMs">Connect (ms)</Label>
                <Input
                  id="timeoutConnectMs"
                  type="number"
                  value={formData.timeoutConnectMs}
                  onChange={(e) => updateField('timeoutConnectMs', parseInt(e.target.value))}
                  min="1000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timeoutRequestMs">Request (ms)</Label>
                <Input
                  id="timeoutRequestMs"
                  type="number"
                  value={formData.timeoutRequestMs}
                  onChange={(e) => updateField('timeoutRequestMs', parseInt(e.target.value))}
                  min="1000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timeoutTotalMs">Total (ms)</Label>
                <Input
                  id="timeoutTotalMs"
                  type="number"
                  value={formData.timeoutTotalMs}
                  onChange={(e) => updateField('timeoutTotalMs', parseInt(e.target.value))}
                  min="1000"
                />
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4 mt-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Health Checks</Label>
                <p className="text-sm text-muted-foreground">Monitor provider availability</p>
              </div>
              <Switch
                checked={formData.healthCheckEnabled}
                onCheckedChange={(checked) => updateField('healthCheckEnabled', checked)}
              />
            </div>

            {formData.healthCheckEnabled && (
              <div className="grid gap-4 md:grid-cols-2 pl-6">
                <div className="space-y-2">
                  <Label htmlFor="healthCheckEndpoint">Health Check Endpoint</Label>
                  <Input
                    id="healthCheckEndpoint"
                    value={formData.healthCheckEndpoint}
                    onChange={(e) => updateField('healthCheckEndpoint', e.target.value)}
                    placeholder="/health or /status"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="healthCheckIntervalSeconds">Check Interval (seconds)</Label>
                  <Input
                    id="healthCheckIntervalSeconds"
                    type="number"
                    value={formData.healthCheckIntervalSeconds}
                    onChange={(e) => updateField('healthCheckIntervalSeconds', parseInt(e.target.value))}
                    min="30"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="healthCheckTimeoutMs">Health Check Timeout (ms)</Label>
                  <Input
                    id="healthCheckTimeoutMs"
                    type="number"
                    value={formData.healthCheckTimeoutMs}
                    onChange={(e) => updateField('healthCheckTimeoutMs', parseInt(e.target.value))}
                    min="1000"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-medium">Webhook Configuration</h4>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="webhookUrl">Webhook URL</Label>
                <Input
                  id="webhookUrl"
                  type="url"
                  value={formData.webhookUrl}
                  onChange={(e) => updateField('webhookUrl', e.target.value)}
                  placeholder="https://your-app.com/webhooks/provider"
                />
                <p className="text-xs text-muted-foreground">Receive events from the provider</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="webhookSecret">Webhook Secret</Label>
                <Input
                  id="webhookSecret"
                  type="password"
                  value={formData.webhookSecret}
                  onChange={(e) => updateField('webhookSecret', e.target.value)}
                  placeholder="Secret for webhook signature verification"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="webhookEvents">Webhook Events (comma-separated)</Label>
                <Input
                  id="webhookEvents"
                  value={formData.webhookEvents.join(', ')}
                  onChange={(e) => updateField('webhookEvents', e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean))}
                  placeholder="order.created, trade.executed, alert.triggered"
                />
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button type="submit" className="w-full sm:w-auto">
          {mode === 'create' ? 'Create Provider' : 'Update Provider'}
        </Button>
      </div>
    </form>
  );
}
